#pragma once
#include <atomic>
#include <cassert>
#include <MandelbrotEngineV2/RenderJob.hpp>

#ifndef CACHE_LINE
#define CACHE_LINE 128
#endif

namespace mandelbrot_engine {

/**
 * @brief: RenderJobStack: fixed size non-blocking SPMC stack data structure
 * * This class implements a fixed size stack like data structure for the MandelbrotEngine
 * frame generation schedule. The structure exposes methods which allow a single concurrent
 * thread to add a new job to the stack or multiple concurrent threads to get the last added
 * job.
 * * When adding the new job, the previous one gets aborted, which would allow worker threads
 * to always detect the latest added job to skip not completed old frames in favor of newer
 * ones. The stack exposes a try_push method which enqueues the provided job only if the selected
 * slot contains a job which is done. A job is considered done when it is completed or it was
 * previously aborted and all threads which could be working on the job observed (at least one time)
 * that said job was aborted. This results in a very simple backpressure effect in case the frame-rate
 * of the enqueuer thread greatly outmatches the rate of completion of a job given a static number
 * of workers.
 * * The structure allows threads to passively wait (via native C++20 std::atomic::wait) using a
 * dedicated versioning state bell, dropping CPU usage to exactly 0% when no jobs are active.
 */
class RenderJobStack {
    // Tracks the absolute chronological generation of the most recently pushed job
    alignas(CACHE_LINE) std::atomic_uint64_t tail{0};

    // Pad the remaining cache line perfectly to prevent false sharing invalidations
    char pad_tail__[CACHE_LINE - (sizeof(std::atomic_uint64_t) * 2)];

    const size_t buf_size__;
    RenderJob* const buf_ptr__;

public:
    /**
     * @brief constructor for RenderJobStack
     * @warning: may throw std::bad_alloc
     */
    RenderJobStack(size_t buf_size):
        buf_size__{buf_size},
        buf_ptr__{new RenderJob[buf_size]}
    {
        assert(buf_size != 0 && "RenderJobStack: buffer size must be non-negative");
    }

    /**
     * @brief: destructor for RenderJobStack
     * simply deallocates the inner buffer
     * @warning: doesn't check if any thread holds a reference to any object of the pool
     */
    ~RenderJobStack() {
        delete[] buf_ptr__;
    }

    RenderJobStack(const RenderJobStack&) = delete;
    RenderJobStack& operator=(const RenderJobStack&) = delete;

    /**
     * @brief: tries to add a new job to the stack
     * @tparam: type of the JobState: either RenderJob::ETAJob or RenderJob::PTBJob
     * @param: RenderJob::JobSpecs specifics of the job
     * @returns true if the job was stacked false otherwise
     * @note: if the method returns true, the previous current job is to be considered aborted
     * @note: this method is to be considered wait-free and is not MT-Safe
     */
    template<typename T, typename... Args>
    bool try_push(RenderJob::JobSpecs specs, Args&&... args) {
        const uint64_t curr_tail = tail.load(std::memory_order_acquire);
        RenderJob& next_slot_job = buf_ptr__[(curr_tail + 1) % buf_size__];

        // Apply backpressure: the buffer is currently full / workers are falling behind
        if(!next_slot_job.done()) return false;

        // Emplace the new job under write-isolation
        next_slot_job.emplace<T>(specs, curr_tail + 1,std::forward<Args>(args)...);

        // Instantly route all upcoming lease acquisitions to the new slot
        tail.store(curr_tail + 1, std::memory_order_release);
        
        // Safely seal and abort the previous frame layout to unblock stranded threads
        RenderJob& curr_job = buf_ptr__[curr_tail % buf_size__];
        curr_job.abort();

        tail.notify_all();
        return true;
    }

    /**
     * @brief: get the last added job
     * @returns: a modifiable RenderJob reference
     * @note: this method is MT-Safe
     */
    RenderJob& getLatest() const {
        return buf_ptr__[tail.load(std::memory_order_acquire) % buf_size__];
    }

    /**
     * @brief: get the status of the last added job
     * @returns: true if the last job added is done (see RenderJob::done())
     * @note: this method is wait-free and MT-Safe
     */
    bool latestDone() const {
        return buf_ptr__[tail.load(std::memory_order_acquire) % buf_size__].done();
    }

    /**
     * @brief: checks if a job is the latest one
     * @param: immutable RenderJob reference
     * @returns true: if the pointer of the argument matches the pointer of the last added job
     * @note: the pointer comparison is guaranteed because the underlying buffer never resizes
     */
    bool isLatest(const RenderJob& j) const {
        const RenderJob* const latest_ptr = buf_ptr__ + (tail.load(std::memory_order_acquire) % buf_size__);
        return (&j) == latest_ptr;
    }

    /**
     * @brief: check if a stamp is the latest one
     * @param: uint64_t stamp
     * @returns: true if the argument stamp is bitwise equal to the latest stamp
     */
    bool isLatestStamp(uint64_t j_stamp) const {
        return tail.load(std::memory_order_acquire) == j_stamp;
    }

    /**
     * @brief: Low-level OS wait putting the thread to sleep securely until the state changes.
     * @param: old_version The version snapshot the thread was acting under.
     * @note: Resolves the 100% CPU spinning issue by yielding hardware control perfectly.
     */
    void wait(uint64_t curr_stamp) const {
        tail.wait(curr_stamp, std::memory_order_acquire);
    }

    /**
     * @brief: Unblocks all waiting threads immediately.
     */
    void notify_all() {
        tail.notify_all();
    }

    /**
     * @brief: Safely shuts down the active job and wakes all waiting threads for joining.
     */
    void finalize() {
        buf_ptr__[tail.load(std::memory_order_acquire) % buf_size__].abort();
        tail.notify_all();
    }

    /**
     * @brief: Cancels the active calculation pipeline instantly and signals threads to re-evaluate.
     */
    void abortLatest() {
        buf_ptr__[tail.load(std::memory_order_acquire) % buf_size__].abort();
        tail.notify_all();
    }
};

} // namespace mandelbrot_engine
