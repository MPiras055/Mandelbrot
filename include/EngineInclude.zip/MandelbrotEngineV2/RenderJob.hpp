#pragma once
#include <cstddef>
#include <variant>
#include <limits>
#include <atomic>
#include <cassert>
#include <vector>
#include <array>
#include <string>
#include <complex>

#ifndef CACHE_LINE
#define CACHE_LINE 128ul
#endif

namespace mandelbrot_engine {

    class EscapeTimeEngine;
    class PerturbationEngine;
    class RenderJobStack;

    using ComplexDouble = std::complex<double>;

    // Golden Reference Record (Contains Taylor Derivatives)
    struct RefRecord {
        ComplexDouble center;
        ComplexDouble A; // 1st Order Derivative (Linear)
        ComplexDouble B; // 2nd Order Derivative (Quadratic)
        ComplexDouble C; // 3rd Order Derivative (Cubic)
    };

    // Phase 1/2 Shared State: Lightweight Blind Reference & Delta Matrix
    struct PerturbationFirstReference {
        std::vector<ComplexDouble> blind_orbit;
        std::array<int, 48 * 48> probe_matrix;

        PerturbationFirstReference() {
            probe_matrix.fill(-1);
        }
    };

    struct RenderJob {
        
        struct JobSpecs {
            unsigned int width{0};
            unsigned int height{0};
            unsigned int iterations{0};
            double xMin{0.0};
            double yMin{0.0};
            double pixelStepX{0.0};
            double pixelStepY{0.0};
            size_t chunks{0};
            bool enableDeltaProbing{true}; // NEW: Toggle flag for Delta Probing
        };

        struct EscapeTimeJobState {
            EscapeTimeJobState()     noexcept = default;
            ~EscapeTimeJobState()    noexcept = default;

            bool done(size_t total_chunks) const noexcept { return (done_chunk.load(std::memory_order_acquire) & (~MSB_MASK)) == total_chunks; }
            bool completed(size_t total_chunks) const noexcept { return done_chunk.load(std::memory_order_acquire) == total_chunks; }
            bool aborted() const noexcept { return (done_chunk.load(std::memory_order_acquire) & MSB_MASK) != 0ul; }
            
            [[nodiscard]] bool getChunk(size_t total_chunks, size_t& chunk_i) noexcept {
                const size_t i = next_chunk.fetch_add(1, std::memory_order_acq_rel);
                if (i >= total_chunks) return false;
                chunk_i = i;
                return true;
            }
            void markCompletedChunk([[maybe_unused]] size_t chunk_i) noexcept {
                (void) done_chunk.fetch_add(1, std::memory_order_release);
            }
            
            private:
            static constexpr size_t MSB_MASK = size_t(1) << (std::numeric_limits<size_t>::digits - 1);
            alignas(CACHE_LINE) std::atomic_size_t next_chunk{0};
            alignas(CACHE_LINE) std::atomic_size_t done_chunk{0};
            char __pad[CACHE_LINE - sizeof(std::atomic_size_t)];

            protected:
            friend RenderJob;
            void reset(size_t total_chunks) noexcept {
                assert((total_chunks & MSB_MASK) == 0 && "total_chunks too high");
                next_chunk.store(0, std::memory_order_relaxed);
                done_chunk.store(0, std::memory_order_relaxed);
            }
            bool abort(size_t total_chunks) noexcept {
                const size_t last = next_chunk.fetch_add(MSB_MASK, std::memory_order_acq_rel);
                if (last < total_chunks) {
                    const size_t flag = (total_chunks - last) | MSB_MASK;
                    done_chunk.fetch_add(flag, std::memory_order_release);
                    return true;
                }
                return false;
            }
        }; 

        struct PerturbationJobState {
            PerturbationJobState()  noexcept = default;
            ~PerturbationJobState() noexcept {
                delete first_ref.load(std::memory_order_relaxed);
                delete golden_ref.load(std::memory_order_relaxed);
            }

            std::string center_x_str;
            std::string center_y_str;

            // Phase 1-4: Blind Reference & Delta Probe Queue
            std::atomic<PerturbationFirstReference*> first_ref{nullptr};
            
            alignas(CACHE_LINE) std::atomic_size_t next_probe{0};
            alignas(CACHE_LINE) std::atomic_size_t done_probe{0};
            char __pad1[CACHE_LINE - sizeof(std::atomic_size_t)];
            
            // Phase 5-6: Golden Reference Race
            std::atomic<std::vector<RefRecord>*> golden_ref{nullptr};

            // Phase 7: Main Render Work Stealing Queue
            alignas(CACHE_LINE) std::atomic_size_t next_chunk{0};
            alignas(CACHE_LINE) std::atomic_size_t done_chunk{0};
            char __pad2[CACHE_LINE - sizeof(std::atomic_size_t)];

            // --- Status Checks ---
            bool done(size_t total_chunks) const noexcept { return (done_chunk.load(std::memory_order_acquire) & (~MSB_MASK)) == total_chunks; }
            bool completed(size_t total_chunks) const noexcept { return done_chunk.load(std::memory_order_acquire) == total_chunks; }
            bool aborted() const noexcept { return (done_chunk.load(std::memory_order_acquire) & MSB_MASK) != 0ul; }
            
            // --- Probe Queue Logic ---
            [[nodiscard]] bool getProbeChunk(size_t total_probes, size_t& chunk_i) noexcept {
                const size_t i = next_probe.fetch_add(1, std::memory_order_acq_rel);
                if (i >= total_probes) return false;
                chunk_i = i;
                return true;
            }
            void markCompletedProbe() noexcept {
                (void) done_probe.fetch_add(1, std::memory_order_release);
            }
            bool probeCompleted(size_t total_probes) const noexcept {
                return done_probe.load(std::memory_order_acquire) == total_probes;
            }

            // --- Render Queue Logic ---
            [[nodiscard]] bool getChunk(size_t total_chunks, size_t& chunk_i) noexcept {
                const size_t i = next_chunk.fetch_add(1, std::memory_order_acq_rel);
                if (i >= total_chunks) return false;
                chunk_i = i;
                return true;
            }
            void markCompletedChunk([[maybe_unused]] size_t chunk_i) noexcept {
                (void) done_chunk.fetch_add(1, std::memory_order_release);
            }
            
            private:
            static constexpr size_t MSB_MASK = size_t(1) << (std::numeric_limits<size_t>::digits - 1);

            protected:
            friend RenderJob;
            void reset(size_t total_chunks, std::string cx = "", std::string cy = "") noexcept {
                assert((total_chunks & MSB_MASK) == 0 && "total_chunks too high");
                
                center_x_str = std::move(cx);
                center_y_str = std::move(cy);
                
                auto* old_first = first_ref.exchange(nullptr, std::memory_order_relaxed);
                delete old_first;

                auto* old_golden = golden_ref.exchange(nullptr, std::memory_order_relaxed);
                delete old_golden;
                
                next_probe.store(0, std::memory_order_relaxed);
                done_probe.store(0, std::memory_order_relaxed);
                next_chunk.store(0, std::memory_order_relaxed);
                done_chunk.store(0, std::memory_order_relaxed);
            }

            bool abort(size_t total_chunks) noexcept {
                next_probe.fetch_or(MSB_MASK, std::memory_order_relaxed); 
                const size_t last = next_chunk.fetch_add(MSB_MASK, std::memory_order_acq_rel);
                if (last < total_chunks) {
                    const size_t flag = (total_chunks - last) | MSB_MASK;
                    done_chunk.fetch_add(flag, std::memory_order_release);
                    return true;
                }
                return false;
            }
        };

        using ETAJob = EscapeTimeJobState;
        using PTBJob = PerturbationJobState;

        [[nodiscard]] inline bool acquire_lease(uint64_t& stamp_ref) noexcept {
            uint64_t previous_state = refCount.fetch_add(1, std::memory_order_acq_rel);
            if ((previous_state & SEAL_BIT) != 0ull) {
                stamp_ref = stamp;
                refCount.fetch_sub(1, std::memory_order_release);
                return false;
            }
            return true;
        }

        inline void release_lease() noexcept { refCount.fetch_sub(1, std::memory_order_release); }
        inline bool done() const noexcept { return std::visit([this](const auto& job) noexcept -> bool { return job.done(specs.chunks); }, jobState); }
        inline bool completed() const noexcept { return std::visit([this](const auto& job) noexcept -> bool { return job.completed(specs.chunks); }, jobState); }
        inline bool aborted() const noexcept { return std::visit([this](const auto& job) noexcept -> bool { return job.aborted(); }, jobState); }

        template<typename T> [[nodiscard]] inline T& getState() noexcept { return std::get<T>(jobState); }
        template<typename T> [[nodiscard]] inline const T& getState_const() const noexcept { return std::get<T>(jobState); }
        uint64_t getStamp() const noexcept { return stamp; }
        JobSpecs getSpecs() const noexcept { return specs; } 
        template<typename T> inline constexpr bool holds() const noexcept { return std::holds_alternative<T>(jobState); }

        private:
        static constexpr uint64_t SEAL_BIT = 1ull << 63;
        friend RenderJobStack;
        uint64_t stamp{};
        JobSpecs specs{};
        alignas(CACHE_LINE) std::atomic_uint64_t refCount{SEAL_BIT};
        char __pad[CACHE_LINE - sizeof(std::atomic_uint64_t)];
        std::variant<ETAJob, PTBJob> jobState;

        template<typename T, typename... Args>
        void emplace(JobSpecs s, uint64_t tag, Args&&... args) {
            assert(is_safe_to_reclaim() && "emplacing job not safe");
            static_assert(std::is_same_v<T, ETAJob> || std::is_same_v<T, PTBJob>, "Invalid type");
            specs = s; 
            if constexpr (std::is_same_v<T, ETAJob>) {
                jobState.emplace<ETAJob>().reset(specs.chunks);
            } else if constexpr (std::is_same_v<T, PTBJob>) {
                jobState.emplace<PTBJob>().reset(specs.chunks, std::forward<Args>(args)...);
            }
            stamp = tag;
            refCount.store(0ull, std::memory_order_release);
        }

        inline void seal() noexcept { refCount.fetch_or(SEAL_BIT, std::memory_order_acq_rel); }

        inline bool abort() noexcept {
            uint64_t old_ref = refCount.fetch_or(SEAL_BIT, std::memory_order_acq_rel);
            bool strategy_aborted = std::visit([this](auto& job) noexcept -> bool { return job.abort(specs.chunks); }, jobState); 
            return (old_ref & SEAL_BIT) == 0ull && strategy_aborted;
        }

        inline bool is_safe_to_reclaim() const noexcept { return refCount.load(std::memory_order_acquire) == SEAL_BIT; }
    };

} // namespace mandelbrot_engine