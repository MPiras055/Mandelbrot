#pragma once
#include <vector>
#include <algorithm>
#include <cmath>
#include <thread>
#include <complex>
#include <boost/multiprecision/cpp_bin_float.hpp>
#include <MandelbrotEngineV2/FrameBuffer.hpp>
#include <MandelbrotEngineV2/RenderJob.hpp>
#include <MandelbrotEngineV2/ColorUtil.hpp>

#if defined(__x86_64__) || defined(_M_X64)
    #include <immintrin.h> 
#endif

namespace mandelbrot_engine {

class MandelbrotEngine;

using BigFloat = boost::multiprecision::cpp_bin_float_50;
using ComplexDouble = std::complex<double>;

class PerturbationEngine {
private:
    FrameBuffer& backBuffer;
    const Gradient& gradient;

    static inline void cpu_relax() {
        #if defined(__x86_64__) || defined(_M_X64)
            _mm_pause();
        #elif defined(__arm__) || defined(__aarch64__)
            asm volatile("yield" ::: "memory");
        #else
            std::this_thread::yield();
        #endif
    }

    PerturbationFirstReference* computeBlindOrbit(
        const RenderJob::PTBJob& job_state, 
        const BigFloat& c_real, 
        const BigFloat& c_imag, 
        unsigned int max_iter
    ) {
        auto* ref = new PerturbationFirstReference();
        ref->blind_orbit.reserve(max_iter);

        BigFloat z_real = 0, z_imag = 0, z_real_sq = 0, z_imag_sq = 0;
        ref->blind_orbit.emplace_back(0.0, 0.0);

        for (unsigned int i = 0; i < max_iter; ++i) {
            if ((i & 63) == 0 && job_state.aborted()) return ref; 

            z_imag = 2.0 * z_real * z_imag + c_imag;
            z_real = z_real_sq - z_imag_sq + c_real;
            z_real_sq = z_real * z_real;
            z_imag_sq = z_imag * z_imag;

            ref->blind_orbit.emplace_back(static_cast<double>(z_real), static_cast<double>(z_imag));

            if ((static_cast<double>(z_real_sq) + static_cast<double>(z_imag_sq)) > 4.0) break; 
        }
        return ref;
    }

    std::vector<RefRecord>* computeGoldenOrbit(
        const RenderJob::PTBJob& job_state, 
        const BigFloat& c_real, 
        const BigFloat& c_imag, 
        unsigned int max_iter
    ) {
        auto* orbit = new std::vector<RefRecord>();
        orbit->reserve(max_iter);

        ComplexDouble Z{0.0}, A{0.0}, B{0.0}, C{0.0};
        orbit->push_back({Z, A, B, C});

        BigFloat z_real = 0, z_imag = 0, z_real_sq = 0, z_imag_sq = 0;

        for (unsigned int i = 0; i < max_iter; ++i) {
            if ((i & 63) == 0 && job_state.aborted()) return orbit; 

            ComplexDouble next_A = (Z * A) * 2.0 + ComplexDouble{1.0, 0.0};
            ComplexDouble next_B = (Z * B) * 2.0 + (A * A);
            ComplexDouble next_C = (Z * C) * 2.0 + (A * B) * 2.0;

            z_imag = 2.0 * z_real * z_imag + c_imag;
            z_real = z_real_sq - z_imag_sq + c_real;
            z_real_sq = z_real * z_real;
            z_imag_sq = z_imag * z_imag;

            Z = ComplexDouble(static_cast<double>(z_real), static_cast<double>(z_imag));
            A = next_A; B = next_B; C = next_C;

            orbit->push_back({Z, A, B, C});

            if ((static_cast<double>(z_real_sq) + static_cast<double>(z_imag_sq)) > 4.0) break; 
        }
        return orbit;
    }

    int evaluateDeltaProbe(double dc_real, double dc_imag, const std::vector<ComplexDouble>& ref_orbit, unsigned int max_iter) {
        double dx = 0.0, dy = 0.0, dx2 = 0.0, dy2 = 0.0;
        unsigned int size = ref_orbit.size();
        
        for (unsigned int i = 0; i < size && i < max_iter; ++i) {
            double zr = ref_orbit[i].real();
            double zi = ref_orbit[i].imag();

            if ((zr + dx)*(zr + dx) + (zi + dy)*(zi + dy) > 4.0) return i;

            double next_dx = 2.0 * (zr * dx - zi * dy) + dx2 - dy2 + dc_real;
            double next_dy = 2.0 * (zr * dy + zi * dx) + 2.0 * dx * dy + dc_imag;

            dx = next_dx; dy = next_dy;
            dx2 = dx * dx; dy2 = dy * dy;
        }
        return size; 
    }

    void executeProbeRow(RenderJob::PTBJob& j, const RenderJob::JobSpecs& specs, size_t row_idx, PerturbationFirstReference& first_ref) {
        double grid_step_x = (specs.width * specs.pixelStepX) / 48.0;
        double grid_step_y = (specs.height * specs.pixelStepY) / 48.0;
        double start_dx = -(specs.width / 2.0) * specs.pixelStepX;
        double start_dy = -(specs.height / 2.0) * specs.pixelStepY;

        double test_dy = start_dy + (row_idx * grid_step_y);

        for (int col = 0; col < 48; ++col) {
            if (j.aborted()) return; 
            double test_dx = start_dx + (col * grid_step_x);
            int iter = evaluateDeltaProbe(test_dx, test_dy, first_ref.blind_orbit, specs.iterations);
            first_ref.probe_matrix[row_idx * 48 + col] = iter;
        }
    }

    void processChunkScalar(RenderJob::PTBJob& job_ref, const RenderJob::JobSpecs specs, const size_t chunk_idx, const std::vector<RefRecord>& golden_orbit, double best_dx, double best_dy) {
        static constexpr size_t BLOCK_SIZE = 32; 
        const unsigned int max_iter = specs.iterations;
        const size_t valid_orbit_size = golden_orbit.size();

        const int tiles_x = (specs.width + BLOCK_SIZE - 1) / BLOCK_SIZE;
        const size_t tile_px = (chunk_idx % tiles_x) * BLOCK_SIZE;
        const size_t tile_py = (chunk_idx / tiles_x) * BLOCK_SIZE;
        const int end_px = std::min(tile_px + BLOCK_SIZE, static_cast<size_t>(specs.width));
        const int end_py = std::min(tile_py + BLOCK_SIZE, static_cast<size_t>(specs.height));

        double base_screen_xMin = -(specs.width / 2.0) * specs.pixelStepX;
        double base_screen_yMin = -(specs.height / 2.0) * specs.pixelStepY;
        
        double max_dc_dist = 0.0;
        for (int vx : {0, (int)(end_px - tile_px)}) {
            for (int vy : {0, (int)(end_py - tile_py)}) {
                double dx = base_screen_xMin + ((tile_px + vx) * specs.pixelStepX) - best_dx;
                double dy = base_screen_yMin + ((tile_py + vy) * specs.pixelStepY) - best_dy;
                max_dc_dist = std::max(max_dc_dist, std::sqrt(dx*dx + dy*dy));
            }
        }

        double tolerance = specs.pixelStepX * 0.1; 
        unsigned int N_skip = 0;
        for (unsigned int i = 1; i < valid_orbit_size; ++i) {
            double b_mag = std::abs(golden_orbit[i].B);
            if (std::isnan(b_mag) || (b_mag * max_dc_dist * max_dc_dist > tolerance)) break;
            N_skip = i;
        }

        Color* const __restrict__ raw_canvas = backBuffer.data();
        double dbl_golden_cx = static_cast<double>(BigFloat(job_ref.center_x_str)) + best_dx;
        double dbl_golden_cy = static_cast<double>(BigFloat(job_ref.center_y_str)) + best_dy;

        for (int py = tile_py; py < end_py; py++) {
            if (job_ref.aborted()) return; 
            Color* const row_ptr = raw_canvas + (py * specs.width);
            double dc_imag = base_screen_yMin + (py * specs.pixelStepY) - best_dy;

            for (int px = tile_px; px < end_px; px++) {
                double dc_real = base_screen_xMin + (px * specs.pixelStepX) - best_dx;

                double dx = 0.0, dy = 0.0;
                unsigned int iter = 0;
                
                if (N_skip > 0 && N_skip < valid_orbit_size) {
                    ComplexDouble dc{dc_real, dc_imag};
                    ComplexDouble delta = (golden_orbit[N_skip].A * dc) + (golden_orbit[N_skip].B * (dc * dc));
                    dx = delta.real();
                    dy = delta.imag();
                    iter = N_skip;
                }

                double z_px_r = 0.0, z_px_i = 0.0;
                double final_r2 = 0.0;
                bool escaped = false;
                bool glitched = false;

                while (iter < valid_orbit_size && iter < max_iter) {
                    if ((iter & 63) == 0 && job_ref.aborted()) return; 

                    double zr = golden_orbit[iter].center.real();
                    double zi = golden_orbit[iter].center.imag();

                    z_px_r = zr + dx;
                    z_px_i = zi + dy;

                    double total_r2 = z_px_r * z_px_r + z_px_i * z_px_i;
                    if (total_r2 > 4.0) {
                        final_r2 = total_r2;
                        escaped = true;
                        break;
                    }

                    double next_dx = 2.0 * (zr * dx - zi * dy) + dx*dx - dy*dy + dc_real;
                    double next_dy = 2.0 * (zr * dy + zi * dx) + 2.0 * dx * dy + dc_imag;

                    if (std::isnan(next_dx) || std::isnan(next_dy)) {
                        glitched = true; break;
                    }

                    dx = next_dx; dy = next_dy;
                    iter++;
                }

                if (!escaped && !glitched && iter == valid_orbit_size && iter < max_iter) {
                    double abs_c_r = dbl_golden_cx + dc_real;
                    double abs_c_i = dbl_golden_cy + dc_imag;

                    while (iter < max_iter) {
                        if ((iter & 63) == 0 && job_ref.aborted()) return; 

                        double temp_r = z_px_r * z_px_r - z_px_i * z_px_i + abs_c_r;
                        double temp_i = 2.0 * z_px_r * z_px_i + abs_c_i;
                        z_px_r = temp_r;
                        z_px_i = temp_i;

                        double r2 = z_px_r * z_px_r + z_px_i * z_px_i;
                        if (r2 > 4.0) {
                            final_r2 = r2;
                            break;
                        }
                        iter++;
                    }
                }

                if (glitched) {
                    row_ptr[px] = Color{255, 0, 255, 255}; 
                } else {
                    row_ptr[px] = ColorUtil::Compute(iter, max_iter, static_cast<float>(final_r2), gradient);
                }
            }
        }
    }

public:
    PerturbationEngine(FrameBuffer& fbuffer, const Gradient& gradient):
        backBuffer(fbuffer), gradient(gradient) {}

    void processPerturbationJob(RenderJob& job) {
        auto& j = job.getState<RenderJob::PTBJob>();
        auto specs = job.getSpecs();

        double best_dx = 0.0;
        double best_dy = 0.0;

        if (specs.enableDeltaProbing) {
            // ---------------------------------------------------------------------
            // PHASE 1 & 2: Blind Reference Center & Cache Race
            // ---------------------------------------------------------------------
            if (j.first_ref.load(std::memory_order_acquire) == nullptr) {
                BigFloat center_r(j.center_x_str);
                BigFloat center_i(j.center_y_str);
                
                auto* my_blind = computeBlindOrbit(j, center_r, center_i, specs.iterations);
                if (j.aborted()) { delete my_blind; return; }

                PerturbationFirstReference* expected = nullptr;
                if (!j.first_ref.compare_exchange_strong(expected, my_blind, std::memory_order_acq_rel)) {
                    delete my_blind; 
                }
            }

            PerturbationFirstReference* first_ref_ptr = nullptr;
            while ((first_ref_ptr = j.first_ref.load(std::memory_order_acquire)) == nullptr) {
                if (j.aborted()) return;
                cpu_relax();
            }

            // ---------------------------------------------------------------------
            // PHASE 3: Collaborative Delta Probing (Work Stealing)
            // ---------------------------------------------------------------------
            size_t probe_id;
            while (j.getProbeChunk(48, probe_id)) { 
                if (j.aborted()) return;
                executeProbeRow(j, specs, probe_id, *first_ref_ptr);
                j.markCompletedProbe();
            }

            // ---------------------------------------------------------------------
            // PHASE 4: Deterministic Winner Selection
            // ---------------------------------------------------------------------
            while (!j.probeCompleted(48)) {
                if (j.aborted()) return;
                cpu_relax();
            }

            int best_iter = -1;
            
            double grid_step_x = (specs.width * specs.pixelStepX) / 48.0;
            double grid_step_y = (specs.height * specs.pixelStepY) / 48.0;
            double start_dx = -(specs.width / 2.0) * specs.pixelStepX;
            double start_dy = -(specs.height / 2.0) * specs.pixelStepY;

            for (int row = 0; row < 48; ++row) {
                double test_dy = start_dy + (row * grid_step_y);
                for (int col = 0; col < 48; ++col) {
                    double test_dx = start_dx + (col * grid_step_x);
                    int esc_iter = first_ref_ptr->probe_matrix[row * 48 + col];

                    if (esc_iter > best_iter) {
                        best_iter = esc_iter;
                        best_dx = test_dx; 
                        best_dy = test_dy;
                    } else if (esc_iter == best_iter) {
                        if ((test_dx*test_dx + test_dy*test_dy) < (best_dx*best_dx + best_dy*best_dy)) {
                            best_dx = test_dx; 
                            best_dy = test_dy;
                        }
                    }
                }
            }
        }

        // ---------------------------------------------------------------------
        // PHASE 5 & 6: Golden Reference Computation & Cache Race
        // ---------------------------------------------------------------------
        if (j.golden_ref.load(std::memory_order_acquire) == nullptr) {
            BigFloat golden_r = BigFloat(j.center_x_str) + best_dx; // Offsets remain 0 if probing was disabled
            BigFloat golden_i = BigFloat(j.center_y_str) + best_dy;

            auto* my_golden = computeGoldenOrbit(j, golden_r, golden_i, specs.iterations);
            if (j.aborted()) { delete my_golden; return; }

            std::vector<RefRecord>* expected = nullptr;
            if (!j.golden_ref.compare_exchange_strong(expected, my_golden, std::memory_order_acq_rel)) {
                delete my_golden; 
            }
        }

        const std::vector<RefRecord>* golden_orbit = nullptr;
        while ((golden_orbit = j.golden_ref.load(std::memory_order_acquire)) == nullptr) {
            if (j.aborted()) return;
            cpu_relax();
        }

        // ---------------------------------------------------------------------
        // PHASE 7: Full Screen Perturbation Rendering
        // ---------------------------------------------------------------------
        size_t chunk_id;
        while (j.getChunk(specs.chunks, chunk_id)) {
            if (j.aborted()) return;
            processChunkScalar(j, specs, chunk_id, *golden_orbit, best_dx, best_dy);
            j.markCompletedChunk(chunk_id);
        }
    }

    static inline size_t CalculateTotalChunks(unsigned int width, unsigned int height) noexcept {
        size_t blocks_x = (width + 31) / 32;
        size_t blocks_y = (height + 31) / 32;
        return blocks_x * blocks_y;
    }       
};

} // namespace mandelbrot_engine