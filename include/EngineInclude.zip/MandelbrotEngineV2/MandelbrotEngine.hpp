#pragma once
#include <raylib.h>
#include <stdexcept>
#include <thread>
#include <vector>
#include <string>
#include <cmath>
// 1. Include the multiprecision library
#include <boost/multiprecision/cpp_bin_float.hpp> 

#include <MandelbrotEngineV2/ColorUtil.hpp>
#include <MandelbrotEngineV2/EscapeTimeEngine.hpp>
#include <MandelbrotEngineV2/PerturbationEngine.hpp>
#include <MandelbrotEngineV2/FrameBuffer.hpp>
#include <MandelbrotEngineV2/RenderJobStack.hpp>

#ifndef CACHE_LINE 
#define CACHE_LINE 128ul
#endif

namespace mandelbrot_engine {

using BigFloat = boost::multiprecision::cpp_bin_float_50;

class MandelbrotEngine {

    enum class JobStrategy {ETA, PERTURBATION};

    // 2. Add string payload containers to the TaggedJobSpecs
    struct TaggedJobSpecs {
        RenderJob::JobSpecs specs;
        JobStrategy strat;
        std::string cx_str;
        std::string cy_str;
    };

    static constexpr double ZOOM_ETA_DOUBLE_THRESH = 1e4;   
    static constexpr double ZOOM_PTB_THRESH = 1e14;         
    static constexpr size_t JOBSTACK_S_DEF = 16;            
    
    Gradient global_gradient_{
        .stops = {
            { 0.00f, Color{ 20, 10, 35, 255 } },     
            { 0.35f, Color{ 135, 35, 65, 255 } },    
            { 0.65f, Color{ 215, 80, 50, 255 } },    
            { 0.90f, Color{ 245, 175, 85, 255 } },   
            { 1.00f, Color{ 255, 235, 190, 255 } }   
        },
        .smooth_shading = true,
        .root_scaling = true
    };
    
    std::vector<std::thread> threadPool;
    alignas(CACHE_LINE) std::atomic_bool stopPool{false};
    char __pad[CACHE_LINE - sizeof(std::atomic_bool)];

    // 3. UPGRADE CAMERA STATE TO BIGFLOAT
    // Zoom remains double because scale magnitude (e.g., 1e30) fits cleanly in 64-bit exponent boundaries
    BigFloat offsetX{-0.5};
    BigFloat offsetY{0.0};
    double zoom{1.0};
    bool deltaProbingOn{false};
    
    BigFloat targetOffsetX{offsetX};
    BigFloat targetOffsetY{offsetY};
    double targetZoom{zoom};

    uint64_t stampLastFlipped;
    FrameBuffer frontBuffer;
    size_t frontWidth{0},frontHeight{0};
    FrameBuffer backBuffer;
    RenderJobStack jobStack;
    
    EscapeTimeEngine etaEngine;
    PerturbationEngine ptbEngine;

    static bool getSystemMaxResolution(unsigned int& height, unsigned int& width) {
        InitWindow(0,0,"SystemProbe");
        unsigned int maxWidth{},maxHeight{},maxArea{};
        unsigned int currWidth{},currHeight{},currArea{};
        for(unsigned int i = 0; i < GetMonitorCount(); i++) {
            currWidth   = GetMonitorWidth(i);
            currHeight  = GetMonitorHeight(i);
            currArea    = currWidth * currHeight;
            if(currArea > maxArea) {
                maxWidth    = currWidth;
                maxHeight   = currHeight;
                maxArea     = currArea;
            }
        }
        if(maxArea == 0) return false;
        width    = maxWidth;
        height   = maxHeight;
        CloseWindow();
        return true;
    }

    TaggedJobSpecs getTaggedJobSpecs(
            unsigned int renderHeight, unsigned int renderWidth,
            unsigned int screenHeight, unsigned int screenWidth,
            unsigned int iterations
        ) {
        double aspect = (double)screenWidth / screenHeight;
        double mathWidth = 3.0 / zoom; 
        double mathHeight = mathWidth / aspect;
        
        // Downcast to double for ETA Engine absolute bounds (Safe: only used when zoom < 1e14)
        double xMin = static_cast<double>(offsetX) - (mathWidth / 2.0);
        double yMin = static_cast<double>(offsetY) - (mathHeight / 2.0);
        double stepX = mathWidth / renderWidth;
        double stepY = mathHeight / renderHeight;
        
        RenderJob::JobSpecs specs;
        specs.height             = renderHeight;
        specs.width              = renderWidth;
        specs.iterations         = iterations;
        specs.xMin               = xMin;
        specs.yMin               = yMin;
        specs.pixelStepX         = stepX;
        specs.pixelStepY         = stepY;
        specs.enableDeltaProbing = deltaProbingOn;
        
        JobStrategy strat = zoom < ZOOM_PTB_THRESH ? JobStrategy::ETA : JobStrategy::PERTURBATION;
        
        // 4. EXTRACT STRINGS FOR THE PERTURBATION ENGINE
        std::string cx = "";
        std::string cy = "";
        if (strat == JobStrategy::PERTURBATION) {
            // Format out to exactly 50 decimals, locking fixed notation so we don't accidentally pass scientific "e" formatting
            cx = offsetX.str(50, std::ios_base::fixed);
            cy = offsetY.str(50, std::ios_base::fixed);
        }

        specs.chunks     = (strat == JobStrategy::ETA ? 
            EscapeTimeEngine::CalculateTotalChunks(renderWidth, renderHeight) : ptbEngine.CalculateTotalChunks(renderWidth,renderHeight));
        
        return {.specs = specs, .strat = strat, .cx_str = cx, .cy_str = cy};
    }

    bool tryDispatchFrame(TaggedJobSpecs tagged) {
        bool done = false;
        if(tagged.strat == JobStrategy::ETA) {
            // Standard ETA dispatch
            done = jobStack.try_push<RenderJob::ETAJob>(tagged.specs);
        } else if (tagged.strat == JobStrategy::PERTURBATION) {
            // 5. VARIADIC DISPATCH: Push the strings into the stack!
            done = jobStack.try_push<RenderJob::PTBJob>(tagged.specs, tagged.cx_str, tagged.cy_str);
        } else {
            assert(false && "tryDispatchFrame: unhandled job strategy");
        }
        return done;
    }

    void workerRoutine(size_t thread_id) {
        uint64_t last_version = jobStack.getLatest().getStamp();
        
        while(!stopPool.load(std::memory_order_relaxed)) {
            auto& job = jobStack.getLatest();
            last_version = job.getStamp();
            if (job.done()) {
                jobStack.wait(last_version);
                continue; 
            }
            
            if(job.acquire_lease(last_version)) { 
                
                if (job.holds<RenderJob::ETAJob>()) {
                    bool use_float = zoom < ZOOM_ETA_DOUBLE_THRESH;
                    if(use_float) 
                        etaEngine.processEscapeTimeJob<float>(job);
                    else
                        etaEngine.processEscapeTimeJob<double>(job);
                } else if (job.holds<RenderJob::PTBJob>()) {
                    ptbEngine.processPerturbationJob(job);
                }
                
                job.release_lease();
                
            } else {    
                jobStack.wait(last_version);
            }
        }
    }

    public:
    void setDeltaProbing(bool deltaProbing) {
        deltaProbingOn = deltaProbing;
    }
    

    MandelbrotEngine(
        unsigned int initialWidth, unsigned int initialHeight,
        unsigned int maxWidth, unsigned int maxHeight
    ) : 
        stampLastFlipped{0},
        frontWidth{initialWidth},
        frontHeight{initialHeight},
        frontBuffer {maxWidth * maxHeight,initialHeight, initialWidth},
        backBuffer  {maxWidth * maxHeight, initialHeight, initialWidth},
        etaEngine(backBuffer,global_gradient_),
        ptbEngine(backBuffer,global_gradient_),
        jobStack(JOBSTACK_S_DEF)
    {
        global_gradient_.prepare();

        unsigned int numCores = std::thread::hardware_concurrency();
        unsigned int poolSize = (numCores > 2) ? (numCores - 1) : 2;

        threadPool.reserve(poolSize);
        for (size_t i = 0; i < poolSize; ++i) {
            threadPool.emplace_back(&MandelbrotEngine::workerRoutine, this, i);
        }
    }

    static MandelbrotEngine create(unsigned int height,unsigned int width) {
        unsigned int sysWidth{0};
        unsigned int sysHeight{0};
        if(!getSystemMaxResolution(sysWidth, sysHeight)) {
            throw std::runtime_error("");
        }
        return MandelbrotEngine(height,width,sysHeight,sysWidth);
    }

    ~MandelbrotEngine() {
        stopPool.store(true, std::memory_order_release);
        jobStack.finalize();

        for (std::thread& worker : threadPool) {
            if (worker.joinable()) {
                worker.join();
            }
        }
    }
    
    // Convert BigFloat back to double ONLY for UI tracking queries
    double getOffsetX() const {return static_cast<double>(targetOffsetX);}
    double getOffsetY() const {return static_cast<double>(targetOffsetY);}
    double getZoom()    const {return zoom;}
    
    void pan(float mouseDeltaX, float mouseDeltaY, unsigned int screenWidth, unsigned int screenHeight) {
        // Boost perfectly handles implicit math mixing floats, doubles, and BigFloats
        targetOffsetX -= BigFloat((mouseDeltaX / screenWidth) * (3.0 / targetZoom));
        targetOffsetY -= BigFloat((mouseDeltaY / screenHeight) * (3.0 * screenHeight / screenWidth) / targetZoom);
    }

    void applyZoom(float wheelMove, 
        unsigned int mouseX, unsigned int mouseY, 
        unsigned int screenWidth, unsigned int screenHeight
    ) {
       if(wheelMove == 0.0f) return; 
       double aspect     = static_cast<double>(screenWidth) / screenHeight;
       double mathWidth  = 3.0 / targetZoom;
       double mathHeight = mathWidth / aspect;
       
       // Boost handles precision mapping seamlessly
       BigFloat mouseMathX_before = targetOffsetX - (mathWidth / 2.0) + ((double)mouseX / screenWidth) * mathWidth;
       BigFloat mouseMathY_before = targetOffsetY - (mathHeight / 2.0) + ((double)mouseY / screenHeight) * mathHeight;
       
       targetZoom *= (wheelMove > 0) ? 1.2 : (1.0 / 1.2);
       
       mathWidth = 3.0 / targetZoom;
       mathHeight = mathWidth / aspect;
       BigFloat mouseMathX_after = targetOffsetX - (mathWidth / 2.0) + ((double)mouseX / screenWidth) * mathWidth;
       BigFloat mouseMathY_after = targetOffsetY - (mathHeight / 2.0) + ((double)mouseY / screenHeight) * mathHeight;
       
       targetOffsetX += (mouseMathX_before - mouseMathX_after);
       targetOffsetY += (mouseMathY_before - mouseMathY_after);
    }

    bool updateCamera() {
        double diffZoom = targetZoom - zoom;
        BigFloat diffX = targetOffsetX - offsetX;
        BigFloat diffY = targetOffsetY - offsetY;
        float dt = std::min(GetFrameTime(), 0.1f);
        double damping = 1.0 - std::exp(-15.0 * dt); 
    
        zoom += diffZoom * damping;
        offsetX += diffX * damping;
        offsetY += diffY * damping;
        
        double moveThreshold = (3.0 / zoom) * 0.0001; 
        
        // Use boost::multiprecision::abs for BigFloat bounds checking
        if (std::abs(diffZoom / zoom) < 0.0001 && boost::multiprecision::abs(diffX) < moveThreshold && boost::multiprecision::abs(diffY) < moveThreshold) {
            zoom = targetZoom;
            offsetX = targetOffsetX;
            offsetY = targetOffsetY;
            return false; 
        } 
        return true; 
    }

    bool tryDispatchFrame(
        unsigned int renderWidth, unsigned int renderHeight,
        unsigned int screenWidth, unsigned int screenHeight,
        unsigned int iterations
    ) {
        return tryDispatchFrame(
            getTaggedJobSpecs(
                renderHeight,renderWidth,
                screenHeight,screenWidth,
                iterations
            )
        );
    }

    void waitFrameDone() {
        while(!jobStack.latestDone()) {
            #if defined(__x86_64__) || defined(_M_X64)
                __builtin_ia32_pause();
            #elif defined(__arm__) || defined(__aarch64__)
                asm volatile("yield" ::: "memory");
            #else
                std::this_thread::yield();
            #endif
        }
    }

    void SetPalette(Gradient new_gradient) 
    {
        jobStack.abortLatest();
        const auto& lastJob = jobStack.getLatest();
        JobStrategy strat = (lastJob.holds<RenderJob::ETAJob>()? JobStrategy::ETA : JobStrategy::PERTURBATION);
        TaggedJobSpecs tagged {.specs = lastJob.getSpecs(),.strat = strat};
        waitFrameDone(); 
        global_gradient_ = std::move(new_gradient);
        global_gradient_.prepare();
        tryDispatchFrame(tagged);
    }

    FrameBuffer::View harvestFrame() {
        const RenderJob& j = jobStack.getLatest();
        bool flipped = false;
        const uint64_t j_stamp = j.getStamp();
        if(j_stamp != stampLastFlipped && j.completed()) {
            RenderJob::JobSpecs j_specs = j.getSpecs();
            frontWidth   = j_specs.width;
            frontHeight  = j_specs.height;
            FrameBuffer::swap(frontBuffer,backBuffer);
            stampLastFlipped = j_stamp;
            flipped = true;
        }
        return frontBuffer.getView(frontHeight,frontWidth,flipped);
    }
};
    
} //namespace mandelbrot_engine