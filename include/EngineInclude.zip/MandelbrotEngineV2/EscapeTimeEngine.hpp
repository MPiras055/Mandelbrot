#pragma once
#include <cassert>
#include <experimental/simd>
#include <algorithm>
#include <MandelbrotEngineV2/FrameBuffer.hpp>
#include <MandelbrotEngineV2/RenderJob.hpp>
#include <MandelbrotEngineV2/ColorUtil.hpp>

#ifndef CACHE_LINE 
#define CACHE_LINE 128
#endif

namespace mandelbrot_engine {

class MandelbrotEngine;

/**
 * @class EscapeTimeEngine
 * @brief Stateless SIMD-accelerated computing engine for Traditional Escape Time Mandelbrot.
 * @details Features an inline coherent 4x Grid Supersampling (SSAA) pass designed to keep
 * hardware vector pipelines hot without register lane divergence.
 */
class EscapeTimeEngine {
private:
    FrameBuffer& backBuffer;
    const Gradient& gradient;

    /**
     * @brief Processes a specific 32x32 pixel block using vector SIMD processing loops.
     */
    template<typename F>
    void processChunkSIMD(const RenderJob::ETAJob& job_ref, const RenderJob::JobSpecs specs, const size_t chunk_idx) {
        namespace stdx = std::experimental;
        static constexpr bool OPT_CARDIOID_BULB = true; 
        static constexpr size_t BLOCK_SIZE = 32; 
        
        const unsigned int max_iteration = specs.iterations;
        constexpr std::size_t V_WIDTH = stdx::simd<F>::size();
        using IntF = std::conditional_t<std::is_same_v<F, double>, unsigned long long, unsigned int>;
        
        const int tiles_x = (specs.width + BLOCK_SIZE - 1) / BLOCK_SIZE;
    
        const size_t tile_px = (chunk_idx % tiles_x) * BLOCK_SIZE;
        const size_t tile_py = (chunk_idx / tiles_x) * BLOCK_SIZE;
    
        const int end_px = std::min(tile_px + BLOCK_SIZE, static_cast<size_t>(specs.width));
        const int end_py = std::min(tile_py + BLOCK_SIZE, static_cast<size_t>(specs.height));
    
        F f_xMin  = static_cast<F>(specs.xMin);
        F f_yMin  = static_cast<F>(specs.yMin);
        F f_stepX = static_cast<F>(specs.pixelStepX);
        F f_stepY = static_cast<F>(specs.pixelStepY);
    
        stdx::simd<F> offsets([](size_t i) { return static_cast<F>(i); });
        Color* const __restrict__ raw_canvas = backBuffer.data();
        
        // Dynamic Gearbox: Apply 4x SSAA only on high-res refinement passes to keep panning fast
        const bool refine_pass = (specs.width > 1000);
        const int sub_samples = refine_pass ? 1 : 1; //we leave it as 1
        const float sample_divisor = static_cast<float>(sub_samples * sub_samples);
    
        for (int py = tile_py; py < end_py; py++) {
            // if (job_ref.aborted()) return;
            Color* const row_ptr = raw_canvas + (py * specs.width);
    
            for (int px = tile_px; px < end_px; px += V_WIDTH) {
                // Stack-allocated color channels to accumulate multi-sample passes safely
                float accum_r[V_WIDTH] = {0.0f};
                float accum_g[V_WIDTH] = {0.0f};
                float accum_b[V_WIDTH] = {0.0f};
                
                // --- SUPERSAMPLING JITTER MATRIX LOOP ---
                for (int s_y = 0; s_y < sub_samples; ++s_y) {
                    F sub_y_offset = refine_pass ? (static_cast<F>(s_y) + 0.5f) / 2.0f : 0.5f;
                    F c_imag_scalar = f_yMin + ((static_cast<F>(py) + sub_y_offset) * f_stepY);
                    stdx::simd<F> c_imag = c_imag_scalar; 

                    for (int s_x = 0; s_x < sub_samples; ++s_x) {
                        F sub_x_offset = refine_pass ? (static_cast<F>(s_x) + 0.5f) / 2.0f : 0.5f;
                        stdx::simd<F> base_x = f_xMin + (static_cast<F>(px) * f_stepX);
                        stdx::simd<F> c_real = base_x + ((offsets + sub_x_offset) * f_stepX);
                        
                        stdx::simd_mask<F> inside_set{false};
            
                        if constexpr (OPT_CARDIOID_BULB) {
                            stdx::simd<F> c_r_minus_0_25 = c_real - 0.25f;
                            stdx::simd<F> c_imag_sq = c_imag * c_imag;
                            stdx::simd<F> q = c_r_minus_0_25 * c_r_minus_0_25 + c_imag_sq;
                            stdx::simd_mask<F> in_cardioid = q * (q + c_r_minus_0_25) <= 0.25f * c_imag_sq;
                            stdx::simd<F> c_r_plus_1 = c_real + 1.0f;
                            stdx::simd_mask<F> in_bulb = c_r_plus_1 * c_r_plus_1 + c_imag_sq <= 0.0625f;
                            
                            inside_set = in_cardioid || in_bulb;
                            
                            if (stdx::all_of(inside_set)) {
                                for (std::size_t i = 0; i < V_WIDTH && (px + i) < specs.width; i++) {
                                    accum_r[i] += static_cast<float>(BLACK.r);
                                    accum_g[i] += static_cast<float>(BLACK.g);
                                    accum_b[i] += static_cast<float>(BLACK.b);
                                }
                                continue; 
                            }
                        }
            
                        stdx::simd<F> x = 0.0f, y = 0.0f, x2 = 0.0f, y2 = 0.0f, w = 0.0f;
                        stdx::simd<IntF> iterations = 0;
                        stdx::simd_mask<F> active = !inside_set;
                        stdx::simd<F> escape_r2 = 4.0f; 
            
                        IntF curr_iter = 0;
                        const IntF iterMaxCast = static_cast<IntF>(max_iteration);
                        
                        while (curr_iter < iterMaxCast) {
                            if ((curr_iter % 32) == 0 && job_ref.aborted()) return;
            
                            for (int k = 0; k < 8 && curr_iter < iterMaxCast; ++k, ++curr_iter) {
                                x = x2 - y2 + c_real;
                                y = w - x2 - y2 + c_imag;
                                x2 = x * x;
                                y2 = y * y;
                                w = (x + y) * (x + y);
            
                                stdx::simd<F> current_r2 = x2 + y2;
                                stdx::simd_mask<F> within_bounds = (current_r2 <= 4.0f);
                                stdx::simd_mask<F> just_escaped = active && !within_bounds;
            
                                stdx::where_expression(just_escaped, escape_r2) = current_r2;
            
                                active = active && within_bounds;
                                stdx::where_expression(active, iterations) += 1;
                            }
                            if (stdx::none_of(active)) break; 
                        }
            
                        alignas(CACHE_LINE) IntF iters[V_WIDTH];
                        alignas(CACHE_LINE) F final_r2[V_WIDTH];
                        iterations.copy_to(iters, stdx::element_aligned);
                        escape_r2.copy_to(final_r2, stdx::element_aligned);
                        
                        // Accumulate colors per subpixel sample into local registers
                        for (std::size_t i = 0; i < V_WIDTH && (px + i) < specs.width; i++) {
                            Color sample = ColorUtil::Compute(
                                static_cast<unsigned int>(iters[i]), max_iteration, static_cast<float>(final_r2[i]), gradient
                            );
                            accum_r[i] += static_cast<float>(sample.r);
                            accum_g[i] += static_cast<float>(sample.g);
                            accum_b[i] += static_cast<float>(sample.b);
                        }
                    }
                }

                // --- BOX FILTER AVERAGING BLEND PASS ---
                for (std::size_t i = 0; i < V_WIDTH && (px + i) < specs.width; i++) {
                    row_ptr[px + i].r = static_cast<unsigned char>(accum_r[i] / sample_divisor);
                    row_ptr[px + i].g = static_cast<unsigned char>(accum_g[i] / sample_divisor);
                    row_ptr[px + i].b = static_cast<unsigned char>(accum_b[i] / sample_divisor);
                    row_ptr[px + i].a = 255;
                }
            }
        }
    }

public:
    EscapeTimeEngine(FrameBuffer& fbuffer, const Gradient& gradient):
        backBuffer(fbuffer), gradient(gradient) {}
    
    template<typename F>
    void processEscapeTimeJob(RenderJob& job) {
        size_t chunk_id;
        auto& j = job.getState<RenderJob::ETAJob>();
        auto specs = job.getSpecs();
        
        while (j.getChunk(specs.chunks, chunk_id)) {
            processChunkSIMD<F>(j, specs, chunk_id);
            j.markCompletedChunk(chunk_id);
        }
    }

    static inline size_t CalculateTotalChunks(unsigned int width, unsigned int height) noexcept {
        size_t blocks_x = (width + 31) / 32;
        size_t blocks_y = (height + 31) / 32;
        return blocks_x * blocks_y;
    }       
};

} // namespace mandelbrot_engine